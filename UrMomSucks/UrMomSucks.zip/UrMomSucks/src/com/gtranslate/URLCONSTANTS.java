package com.gtranslate;

public class URLCONSTANTS {
	public static final String GOOGLE_TRANSLATE_TEXT = "http://translate.google.com/translate_a/t?";
	public static final String GOOGLE_TRANSLATE_AUDIO = "http://translate.google.com/translate_tts?";
	// v=1.0&q=alemao
	public static final String GOOGLE_TRANSLATE_DETECT = "http://www.google.com/uds/GlangDetect?";

}
