package com.gtranslate.parsing;

public interface Parse {
	void parse();
	void appendURL();
}
