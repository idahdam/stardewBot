package com.idahdam.urmommakesthebestpizza;

// https://github.com/kristian/system-hook
// https://github.com/wihoho/java-google-translate-text-to-speech

import java.awt.*;

public class Main {

    public static void main(String[] args) throws AWTException {
            DetectingKey start = new DetectingKey();
            start.KeyDetector();
    }
}
